package sel.toast;

/**
 * The types of slots in the toaster.
 */
public enum SlotType {
  REGULAR, WIDE
}
